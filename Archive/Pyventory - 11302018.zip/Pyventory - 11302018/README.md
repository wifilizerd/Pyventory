# Pyventory
Python based Asset checker, Adding Scan and Check features to any CSV database.

SETUP:
1. download Master-Pyventry.zip and extract all files, pyventory only requiers that python 2.7+ is installed (has not been tested using Python3+).
2. copy export of inventory CSV file into the pyventory folder.
3. run pyventory.

Current Features:
Enter/Scan barcodes and pyventory will use teh inventory file provided to check if the barcode is in the list. 

items that were not found in the inventory list, user will be prompted to eather enter the missing info or skip.
    Feature can be turned on and off.

Export a list of all items that have not been scanned, and any items that were not found. 

if item in list did not contain the into you are looking for it will list those items in a missingINFO file.

Changelog:
0.6.1 - Added room feature that allows user to search only barcodes that are located in a specified room, pyventory will if the barcode is found and room is incorrect will shoe current known data and note the new room number for latter update.
0.6 - after months of testing and reworking pyventory is now ready to be posted on GitHub,


Warrenty:
THERE IS NONE, by using this probram you agree that there is no warrenty and that this program is free to use at your own risk.
this is all my personal time, so that means that any bug reports will take some time to get to. 

Tested On:
Windows 10 with python 2.7,
Macos X 10.12 with python 2.7 and python 3

Enjoy!
